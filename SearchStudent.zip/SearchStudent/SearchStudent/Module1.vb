﻿Module Module1
    Structure student
        Dim name As String
        Dim mark1 As Double
        Dim mark2 As Double
        Public Overrides Function ToString() As String
            Return String.Format("Name: {0}, mark1: {1} , mark2:{2}", name, mark1, mark2)
        End Function

    End Structure

    Sub Main()
        'Dim ArrSearch(0) As student
        'Dim st As student
        'st.name = "steve"
        'st.mark1 = 5.3
        'st.mark2 = 7.5
        'ArrSearch(0) = st
        'ReDim Preserve ArrSearch(ArrSearch.Length + 1)
        'st.name = "sumei"
        'st.mark1 = 5.5
        'st.mark2 = 6.5
        'ArrSearch(1) = st
        'ReDim Preserve ArrSearch(ArrSearch.Length + 1)
        'st.name = "daniel"
        'st.mark1 = 5.5
        'st.mark2 = 8.5
        'ArrSearch(2) = st

        'Dim Sname As String
        'Dim i As Integer
        'Console.WriteLine("Enter the student's name")
        'Sname = Console.ReadLine()
        'For i = 0 To ArrSearch.Length - 1
        '    If ArrSearch(i).name = Sname Then
        '        Console.WriteLine("Name: " + ArrSearch(i).name + " mark1: " + Str(ArrSearch(i).mark1) + " mark2: " + Str(ArrSearch(i).mark2))
        '    End If
        'Next

        'Dim mark As Double
        'Console.WriteLine("Enter the student's mark")
        'mark = Console.ReadLine()
        'For i = 0 To ArrSearch.Length - 1
        '    If ArrSearch(i).mark1 = mark Or ArrSearch(i).mark2 = mark Then
        '        Console.WriteLine("Name: " + ArrSearch(i).name + " mark1: " + Str(ArrSearch(i).mark1) + " mark2: " + Str(ArrSearch(i).mark2))
        '    End If
        'Next
        'Console.ReadLine()
        Dim Arr_Student(0) As student
        Dim st As student
        Dim opt, cond, i As Integer
        cond = 1
        Dim Sname As String
        Dim mark As Double
        Do
            Console.WriteLine(" Menu " + vbCrLf + "......")
            Console.WriteLine("1.Add Student")
            Console.WriteLine("2.Search student by name")
            Console.WriteLine("3.Search student by mark")
            Console.WriteLine("4.Print the student")
            Console.WriteLine("5.Quit")
            opt = CInt(Console.ReadLine())
            Select Case opt
                Case 1
                    ReDim Preserve Arr_Student(Arr_Student.Length + 1 - 1)
                    Console.WriteLine("Enter a name:")
                    st.name = Console.ReadLine()
                    Console.WriteLine("Enter mark 1:")
                    st.mark1 = Console.ReadLine()
                    Console.WriteLine("Enter mark 2:")
                    st.mark2 = Console.ReadLine()
                    Arr_Student(Arr_Student.Length - 1) = st

                Case 4
                    For i = 1 To Arr_Student.Length - 1
                        Console.WriteLine(Arr_Student(i))
                    Next
                Case 2
                    Console.WriteLine("Enter the student's name")
                    Sname = Console.ReadLine()
                    For i = 0 To Arr_Student.Length - 1
                        If Arr_Student(i).name = Sname Then
                            Console.WriteLine(Arr_Student(i))
                        End If
                    Next
                Case 3
                    Console.WriteLine("Enter the student's mark")
                    mark = Console.ReadLine()
                    For i = 0 To Arr_Student.Length - 1
                        If Arr_Student(i).mark1 = mark Or Arr_Student(i).mark2 = mark Then
                            Console.WriteLine(Arr_Student(i))
                        End If
                    Next
                Case Else
                    Console.WriteLine("Option is not available")

            End Select

        Loop While (opt <> 5)
        Console.WriteLine("ByeBye")
        Console.ReadLine()



    End Sub

End Module

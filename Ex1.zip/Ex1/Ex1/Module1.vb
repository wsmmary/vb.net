﻿Module Module1

    Sub Main()
        Dim a As Short
        Dim b As Integer
        Dim c As Double

        a = 10
        b = 20
        c = a + b
        'This is a comment

        Console.WriteLine("a={0},b={1},c={2}", a, b, c)
        Console.ReadLine()


    End Sub

End Module

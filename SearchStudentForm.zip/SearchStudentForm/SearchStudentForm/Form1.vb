﻿Public Class Form1
    Structure student
        Dim name As String
        Dim mark1 As Double
        Dim mark2 As Double
        Public Overrides Function ToString() As String
            Return String.Format("Name: {0}, mark1: {1} , mark2:{2}", name, mark1, mark2)
        End Function
    End Structure

    Dim Arr_Student(0) As student
    Dim st As student
    Private Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
        ReDim Preserve Arr_Student(Arr_Student.Length + 1 - 1)
        st.name = Txt1.Text
        st.mark1 = Txt2.Text
        st.mark2 = Txt3.Text
        Arr_Student(Arr_Student.Length - 1) = st


        lbl4.Text = lbl4.Text + Arr_Student(Arr_Student.Length - 1).ToString & vbCrLf
        Txt1.Text = ""
        Txt2.Text = ""
        Txt3.Text = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Sname As String
        Sname = txt4.Text
        For i = 0 To Arr_Student.Length - 1
            If Arr_Student(i).name = Sname Then
                lbl5.Text = lbl5.Text + Arr_Student(i).ToString & vbCrLf
            End If
        Next
    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim mark As Double
        mark = txt5.Text
        For i = 0 To Arr_Student.Length - 1
            If Arr_Student(i).mark1 = mark Or Arr_Student(i).mark2 = mark Then
                lbl6.Text = lbl6.Text + Arr_Student(i).ToString & vbCrLf
            End If
        Next
    End Sub
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.txt2 = New System.Windows.Forms.TextBox()
        Me.add = New System.Windows.Forms.Button()
        Me.minus = New System.Windows.Forms.Button()
        Me.prod = New System.Windows.Forms.Button()
        Me.div = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(51, 31)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(37, 13)
        Me.lbl1.TabIndex = 0
        Me.lbl1.Text = "Input1"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(49, 63)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(37, 13)
        Me.lbl2.TabIndex = 1
        Me.lbl2.Text = "Input2"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Location = New System.Drawing.Point(47, 98)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(37, 13)
        Me.lbl3.TabIndex = 2
        Me.lbl3.Text = "Result"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Location = New System.Drawing.Point(102, 98)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(13, 13)
        Me.lbl4.TabIndex = 3
        Me.lbl4.Text = "0"
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(105, 31)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(173, 20)
        Me.txt1.TabIndex = 4
        '
        'txt2
        '
        Me.txt2.Location = New System.Drawing.Point(105, 63)
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(173, 20)
        Me.txt2.TabIndex = 5
        '
        'add
        '
        Me.add.Location = New System.Drawing.Point(50, 134)
        Me.add.Name = "add"
        Me.add.Size = New System.Drawing.Size(52, 23)
        Me.add.TabIndex = 6
        Me.add.Text = "+"
        Me.add.UseVisualStyleBackColor = True
        '
        'minus
        '
        Me.minus.Location = New System.Drawing.Point(108, 134)
        Me.minus.Name = "minus"
        Me.minus.Size = New System.Drawing.Size(52, 23)
        Me.minus.TabIndex = 7
        Me.minus.Text = "-"
        Me.minus.UseVisualStyleBackColor = True
        '
        'prod
        '
        Me.prod.Location = New System.Drawing.Point(166, 134)
        Me.prod.Name = "prod"
        Me.prod.Size = New System.Drawing.Size(57, 23)
        Me.prod.TabIndex = 8
        Me.prod.Text = "*"
        Me.prod.UseVisualStyleBackColor = True
        '
        'div
        '
        Me.div.Location = New System.Drawing.Point(229, 134)
        Me.div.Name = "div"
        Me.div.Size = New System.Drawing.Size(49, 23)
        Me.div.TabIndex = 9
        Me.div.Text = "/"
        Me.div.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(336, 184)
        Me.Controls.Add(Me.div)
        Me.Controls.Add(Me.prod)
        Me.Controls.Add(Me.minus)
        Me.Controls.Add(Me.add)
        Me.Controls.Add(Me.txt2)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl1 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents txt1 As TextBox
    Friend WithEvents txt2 As TextBox
    Friend WithEvents add As Button
    Friend WithEvents minus As Button
    Friend WithEvents prod As Button
    Friend WithEvents div As Button
End Class

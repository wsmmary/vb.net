﻿Public Class Form1
    Dim result As Double

    Private Sub prod_Click(sender As Object, e As EventArgs) Handles prod.Click
        result = CDbl(txt1.Text) * CDbl(txt2.Text)
        lbl4.Text = result
    End Sub

    Private Sub div_Click(sender As Object, e As EventArgs) Handles div.Click
        result = CDbl(txt1.Text) / CDbl(txt2.Text)
        lbl4.Text = result
    End Sub


    Private Sub minus_Click(sender As Object, e As EventArgs) Handles minus.Click
        result = CDbl(txt1.Text) - CDbl(txt2.Text)
        lbl4.Text = result
    End Sub

    Private Sub add_Click(sender As Object, e As EventArgs) Handles add.Click
        result = CDbl(txt1.Text) + CDbl(txt2.Text)
        lbl4.Text = result
    End Sub
End Class

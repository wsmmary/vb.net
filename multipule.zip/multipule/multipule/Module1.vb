﻿Module Module1

    Sub Main()
        Dim i, j As Integer
        i = 1
        j = 1
        While (i <= 4)
            While (j <= 10)
                Console.WriteLine(Str(i) + "*" + Str(j) + "=" + Str(i * j))
                j += 1
            End While
            Console.WriteLine()
            j = 1
            i += 1
        End While

        Console.ReadLine()
    End Sub

End Module

﻿Public Class Form1
    Dim oper As Integer
    Dim num1, num2 As Double

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        If txt1.Text = "0" Then
            txt1.Text = "9"
        Else
            txt1.Text = txt1.Text + "9"
        End If

    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        If txt1.Text = "0" Then
            txt1.Text = "8"
        Else
            txt1.Text = txt1.Text + "8"
        End If
    End Sub

    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        If txt1.Text = "0" Then
            txt1.Text = "7"
        Else
            txt1.Text = txt1.Text + "7"
        End If
    End Sub

    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        If txt1.Text = "0" Then
            txt1.Text = "6"
        Else
            txt1.Text = txt1.Text + "6"
        End If
    End Sub

    Private Sub btn5_Click(sender As Object, e As EventArgs) Handles btn5.Click
        If txt1.Text = "0" Then
            txt1.Text = "5"
        Else
            txt1.Text = txt1.Text + "5"
        End If

    End Sub

    Private Sub btn6_Click(sender As Object, e As EventArgs) Handles btn6.Click
        If txt1.Text = "0" Then
            txt1.Text = "4"
        Else
            txt1.Text = txt1.Text + "4"
        End If

    End Sub

    Private Sub btn7_Click(sender As Object, e As EventArgs) Handles btn7.Click
        If txt1.Text = "0" Then
            txt1.Text = "3"
        Else
            txt1.Text = txt1.Text + "3"
        End If

    End Sub

    Private Sub btn8_Click(sender As Object, e As EventArgs) Handles btn8.Click
        If txt1.Text = "0" Then
            txt1.Text = "2"
        Else
            txt1.Text = txt1.Text + "2"
        End If

    End Sub

    Private Sub btn9_Click(sender As Object, e As EventArgs) Handles btn9.Click
        If txt1.Text = "0" Then
            txt1.Text = "1"
        Else
            txt1.Text = txt1.Text + "1"
        End If


    End Sub

    Private Sub btn10_Click(sender As Object, e As EventArgs) Handles btn10.Click
        txt1.Text = txt1.Text + "0"
    End Sub

    Private Sub btn11_Click(sender As Object, e As EventArgs) Handles btn11.Click
        txt1.Text = txt1.Text + "."
    End Sub

    Private Sub btn13_Click(sender As Object, e As EventArgs) Handles btn13.Click

        oper = 1
        If txt1.Text <> "" Then
            num1 = CDbl(txt1.Text)
        Else
            num1 = 0
        End If
        txt1.Text = txt1.Text + "+"

    End Sub

    Private Sub btn14_Click(sender As Object, e As EventArgs) Handles btn14.Click
        oper = 2
        If txt1.Text <> "" Then
            num1 = CDbl(txt1.Text)
        Else
            num1 = 0
        End If
        txt1.Text = txt1.Text + "-"
    End Sub

    Private Sub btn15_Click(sender As Object, e As EventArgs) Handles btn15.Click
        oper = 3
        If txt1.Text <> "" Then
            num1 = CDbl(txt1.Text)
        Else
            num1 = 0
        End If
        txt1.Text = txt1.Text + "*"
    End Sub

    Private Sub btn16_Click(sender As Object, e As EventArgs) Handles btn16.Click
        oper = 4
        If txt1.Text <> "" Then
            num1 = CDbl(txt1.Text)
        Else
            num1 = 0
        End If
        txt1.Text = txt1.Text + "/"
    End Sub

    Private Sub btn17_Click(sender As Object, e As EventArgs) Handles btn17.Click
        txt1.Text = ""
    End Sub

    Private Sub btn12_Click(sender As Object, e As EventArgs) Handles btn12.Click
        If oper = 1 Then
            Dim loc As Integer = InStr(txt1.Text, "+")
            Dim len As Integer = txt1.Text.Length

            num2 = Mid(txt1.Text, loc + 1, (len - loc))

            txt1.Text = num1 + num2
        End If
        If oper = 2 Then
            Dim loc As Integer = InStr(txt1.Text, "-")
            Dim len As Integer = txt1.Text.Length

            num2 = Mid(txt1.Text, loc + 1, (len - loc))

            txt1.Text = num1 - num2
        End If
        If oper = 3 Then
            Dim loc As Integer = InStr(txt1.Text, "*")
            Dim len As Integer = txt1.Text.Length

            num2 = Mid(txt1.Text, loc + 1, (len - loc))

            txt1.Text = num1 * num2
        End If
        If oper = 4 Then
            Dim loc As Integer = InStr(txt1.Text, "/")
            Dim len As Integer = txt1.Text.Length

            num2 = Mid(txt1.Text, loc + 1, (len - loc))

            txt1.Text = num1 / num2
        End If
    End Sub
End Class

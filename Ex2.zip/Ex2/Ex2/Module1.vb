﻿Module Module1

    Sub Main()
        Dim txt As String
        Console.Write("Enter text: ")
        txt = Console.ReadLine
        Console.WriteLine()
        Console.WriteLine("Your text is :{0}", txt)
        Console.ReadLine()

    End Sub

End Module
